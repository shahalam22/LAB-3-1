public class RusticChair implements Chair {
    @Override
    public void display() {
        System.out.println("Rustic Chair");
    }
}
