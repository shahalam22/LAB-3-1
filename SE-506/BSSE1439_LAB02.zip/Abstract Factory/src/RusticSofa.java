public class RusticSofa implements Sofa{
    @Override
    public void display() {
        System.out.println("Rustic Sofa");
    }
}
