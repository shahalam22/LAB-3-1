public class ModernChair implements Chair{
//    private Number id = null;


    @Override
    public void display() {
        System.out.println("Modern Chair");
    }
}
