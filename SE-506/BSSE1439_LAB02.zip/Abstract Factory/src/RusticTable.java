public class RusticTable implements Table{
    @Override
    public void display() {
        System.out.println("Rustic Table");
    }
}
