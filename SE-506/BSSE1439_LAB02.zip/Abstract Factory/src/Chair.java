public interface Chair {
    public void display();
}
