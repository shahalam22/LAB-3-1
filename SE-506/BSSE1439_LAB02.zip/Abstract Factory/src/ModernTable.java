public class ModernTable implements Table{
    @Override
    public void display() {
        System.out.println("Modern Table");
    }
}
