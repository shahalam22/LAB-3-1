public interface Sofa {
    public void display();
}
