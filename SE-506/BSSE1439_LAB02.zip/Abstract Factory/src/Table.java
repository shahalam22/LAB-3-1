public interface Table {
    public void display();
}
