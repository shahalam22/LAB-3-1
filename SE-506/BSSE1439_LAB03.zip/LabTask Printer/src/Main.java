public class Main {
    public static void main(String[] args) {
//        Department hrdept = new HR("HR", 001, "MR.A");
//        Department markdept = new Marketing("Marketing", 002, "MR.B");
//        Department itdept = new IT("IT", 003, "MR.C");
//
//        hrdept.print("Task 1 of HR department");
//        hrdept.print("Task 2 of HR department");
//        markdept.print("Task 1 of Marketing department");
//        markdept.print("Task 2 of Marketing department");
//        itdept.print("Task 1 of IT department");
//        itdept.print("Task 2 of IT department");
//
//
//
        Department abcdept = new ABC("IT", 003, "MR.C");

        abcdept.print("Task 2 of ABC department");
        abcdept.print("Task 3 of ABC department");
    }
}
