abstract class Printer {
    public abstract void print(String file);
}