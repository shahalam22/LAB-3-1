abstract class Department {

    public abstract void print(String file);
}
