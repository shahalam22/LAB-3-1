public enum SandwichType {
    CHICKEN_SANDWICH, EGG_SANDWICH
}
