public interface Builder {
    void setSandwichType(SandwichType type);
    void setBreadType(String bread);
    void setFillings(String fillings);
    void setSpreads(String spread);
}
