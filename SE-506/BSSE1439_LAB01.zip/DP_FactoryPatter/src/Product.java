abstract class Product {
    public abstract void powerOn();
    public abstract void powerOff();

    public abstract void display();
//    public abstract void display();
}