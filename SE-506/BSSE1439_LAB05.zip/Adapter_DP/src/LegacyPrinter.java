public class LegacyPrinter{
    public void oldPrint(String content){
        System.out.println("Legacy Printer is printing "+content);
    }
}