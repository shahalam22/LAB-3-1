public class ModernPrinter implements Printer {
    @Override
    public void print(String content) {
        System.out.println("Modern Printer is printing: "+content);
    }
}