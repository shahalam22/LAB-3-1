public interface Printer {
    void print(String content);
}






