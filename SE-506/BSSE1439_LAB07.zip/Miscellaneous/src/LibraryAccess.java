public interface LibraryAccess {
    void accessItem(String itemId, User user);
}
