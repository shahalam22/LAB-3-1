public interface LibraryItem {
    String getId();
    String getDetails();
    void borrowItem();
}
