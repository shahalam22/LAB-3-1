
<div id="menu">
    <a href="index.php">home</a> | <a href="list.php">list</a> | <a href="contact.php">contact</a> | <a href="#">home</a>
</div>