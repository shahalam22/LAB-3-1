<div id="footer">Copyrigth &copy; 2025</div>
</div>
</body>
    </html>