<html>
    <head>
        <style>
            body{
                min-height:550px;
            }
#content{
    width:90%;
    margin: 0 auto;
    padding:0px;
    background-color:gray;
}
#header{
    height: 100px;
    background-color:#EFB036;
}
#main_content{
    height:400px;
    background-color:#3B6790;
}
#footer{
    height:100px;
    background-color:#4C7B8B;
    text-align: center;
}
#menu {
    height:20px;
    color:white;
    background-color:#23486A;
}
#menu a{
    color:white;
}

</style>

</head>
<body>
<div id="content">
<div id="header">IIT, DU</div>