<?php
include("header.php");
include("menu.php");
?>
<div id="main_content">This is contact page</div>
<?php
include("footer.php");
?>