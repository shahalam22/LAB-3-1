<?php
include("header.php");
include("menu.php");
?>
<div id="main_content">This is about page</div>
<?php
include("footer.php");
?>