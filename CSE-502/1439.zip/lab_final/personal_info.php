<?php include 'includes/header.php'; ?>
<div class="personal-info">
    <h2>Personal Information</h2>
    <div class="info-section">
        <div class="info-item">
            <span class="info-label">First Name:</span>
            <span class="info-value">Shah Alam</span>
        </div>
        <div class="info-item">
            <span class="info-label">Last Name:</span>
            <span class="info-value">Abir</span>
        </div>
        <div class="info-item">
            <span class="info-label">Father's Name:</span>
            <span class="info-value">Siddikur Rahman</span>
        </div>
        <div class="info-item">
            <span class="info-label">Mother's Name:</span>
            <span class="info-value">Monowara Begum</span>
        </div>
        <div class="info-item">
            <span class="info-label">Date of Birth:</span>
            <span class="info-value">September 09, 2004</span>
        </div>
        <div class="info-item">
            <span class="info-label">Address:</span>
            <span class="info-value">Secretariat Lane, Rally<br>Bandar, Narayanganj, Bangladesh</span>
        </div>
        <div class="info-item">
            <span class="info-label">Email:</span>
            <span class="info-value">shahalamabir21@gmail.com</span>
        </div>
        <div class="info-item">
            <span class="info-label">Phone:</span>
            <span class="info-value">01869230211</span>
        </div>
    </div>
</div>
<?php include 'includes/footer.php'; ?>