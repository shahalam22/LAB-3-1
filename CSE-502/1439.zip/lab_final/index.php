<?php include 'includes/header.php'; ?>
<h1>Welcome to My Portfolio</h1>
<p>Thank you for visiting my personal website!</p>
<?php include 'includes/footer.php'; ?>