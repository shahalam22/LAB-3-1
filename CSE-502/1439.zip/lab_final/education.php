<?php include 'includes/header.php'; ?>
<h2>Educational Background</h2>
<div class="info-card">
    <h3>Software Engineering Degree</h3>
    <p><strong>University:</strong> University of Dhaka</p>
    <p><strong>Years:</strong> 2022-Running</p>
    <p><strong>Relevant Courses:</strong> Web Development, Databases, Algorithms, Cyber Security</p>
</div>
<div class="info-card">
    <h3>HSC</h3>
    <p><strong>College:</strong> Dhaka College</p>
    <p><strong>Graduation Year:</strong> 2021</p>
</div>
<div class="info-card">
    <h3>SSC</h3>
    <p><strong>School:</strong> I.E.T. Govt. High School</p>
    <p><strong>Graduation Year:</strong> 2019</p>
</div>
<?php include 'includes/footer.php'; ?>