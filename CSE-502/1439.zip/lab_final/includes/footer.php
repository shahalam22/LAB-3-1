</div> <!-- container end -->
    <footer id="copyright">
        <p>&copy; 2023 My Portfolio. All rights reserved.</p>
    </footer>
    <script src="js/1439.js"></script>
</body>
</html>